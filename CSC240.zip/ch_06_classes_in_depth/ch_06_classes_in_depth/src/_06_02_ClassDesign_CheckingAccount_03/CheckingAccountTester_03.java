package _06_02_ClassDesign_CheckingAccount_03;

class CheckingAccount {
    // instance variables
    private final String accountNumber;
    private final String accountHolder;
    private double balance;
    //constructors
    CheckingAccount(String accountnumebr, String holder, double balance) {
        this.accountNumber = accountnumebr;
        this.accountHolder = holder;
        this.balance = balance;
    }
    // methods
    public double getBalance() {
        return balance;
    }

    public void processDeposit(double depositAmount) {
        balance = balance + depositAmount;
    }

    public void processCheck(double checkAmount) {
        double charge;
        if (balance < 100000) {
            charge = 15;
        } else {
            charge = 0;
        }

        balance = balance - checkAmount - charge;
    }

    public void display() {
        System.out.println(accountNumber + "\t" + accountHolder + "\t" + balance);
    }
}

class CheckingAccountTester_03 {

    public static void main(String[] args) {
        CheckingAccount account1 = new CheckingAccount("555-88-OD", "Diana", 450);
        account1.display();
        account1.processDeposit(2000);
        account1.processCheck(1500);
        account1.display();

        CheckingAccount account2 = new CheckingAccount("007", "James Bond", 50000);
        account2.display();
        account2.processDeposit(70000);
        account2.processCheck(10000);
        account2.display();

        CheckingAccount account3;
        account3 = account1;
        account3.display();

        if (account1 == account3) {
            System.out.println("An alias has been detected!");
        } else {
            System.out.println("These are different objects!");
        }
    }
}
