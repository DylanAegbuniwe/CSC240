package _06_02_ClassDesign_CheckingAccount_01;

class CheckingAccount {

    // instance variables
    public String accountNumber;
    public String accountHolder;
    public double balance;

    //constructors
    
    // This is what we called a default constructor
    CheckingAccount() {
        
    }

    // methods to follow
}

class CheckingAccountTester_01 {

    public static void main(String[] args) {
      
        
         CheckingAccount account2 = new CheckingAccount();
        System.out.println(account2.accountNumber + " "
                + account2.accountHolder + " " + account2.balance);
    }
}
