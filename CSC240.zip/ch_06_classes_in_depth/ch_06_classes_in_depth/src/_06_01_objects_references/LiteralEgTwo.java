package _06_01_objects_references;

class LiteralEgTwo {

    public static void main(String[] args) {
        String str1 = "String literal";  // create a literal
        String str2 = "String literal";  // str2 refers to the same literal
        String str3 = "String LIteral";  // str3 refers to the same literal

        System.out.println(str1);
        System.out.println(str2);
        System.out.println(str3);

        String msgA = new String("Look Out!");  // create an object
        String msgB = new String("Look Out!");  // create another object
        String msgC = new String("Look Out!");  // create another object

        System.out.println(msgA);
        System.out.println(msgB);
        System.out.println(msgC);
        System.out.println(msgA.toString());

        if (str1 == str2) {
            System.out.println("This WILL print1.");
        }

        if (str1.equals(str2)) {
            System.out.println("This WILL print2.");
        }

        if (msgA == msgB) {
            System.out.println("This will NOT print.");
        }

        if (msgA.equals(msgB)) {
            System.out.println("This WILL print3.");
        }
    }
}
