package _06_04_static_methods_and_variables;

public class StaticMethods_01_Messages {

    public static void main(String[] args) {
        StaticMethods_01_Messages.message1();
        message2();
        System.out.println("Good Bye.");
    }

    public static void message1() {
        System.out.println("This is message1.");
    }

    public static void message2() {
        System.out.println("This is message2.");
    }
    // Where to add new lines or breaks ??
    // System.out.println(" ************** ");
}