package _06_04_static_methods_and_variables;

import java.util.Scanner;

/**
 * Class of non static methods to perform dimension conversions.
 */

class DCWithoutStaticMethods {

    private static final int INCHES_PER_FOOT = 12;

    public  double convertFeetToInches(double feet) {
        return feet * INCHES_PER_FOOT;
    }

    public  double convertInchesToFeet(double inches) {
        return inches / INCHES_PER_FOOT;
    }
}

public class StaticMethods_03_DimensionConverter_01 {

    public static void main(String[] args) {
        
        DCWithoutStaticMethods myCopy = new DCWithoutStaticMethods();
        
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter a measurement in inches: ");
        double inches = keyboard.nextDouble();

        double feet = myCopy.convertInchesToFeet(inches);
        System.out.println(inches + " inches = " + feet + " feet.");

        System.out.print("Enter a measurement in feet: ");
        feet = keyboard.nextDouble();

        inches = myCopy.convertFeetToInches(feet);
        System.out.println(feet + " feet = " + inches + " inches.");
    }
}
