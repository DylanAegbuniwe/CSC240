package _06_04_static_methods_and_variables;

import java.util.Scanner;

/**
 * Class of static methods to perform dimension conversions.
 */

class DCWithStaticMethods {

    private static final int INCHES_PER_FOOT = 12;

    public static double convertFeetToInches(double feet) {
        //INCHES_PER_FOOT++;
        return feet * INCHES_PER_FOOT;
        
    }

    public static double convertInchesToFeet(double inches) {
        return inches / INCHES_PER_FOOT;
    }
}

public class StaticMethods_03_DimensionConverter_02 {

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Enter a measurement in inches: ");
        double inches = keyboard.nextDouble();

        double feet = DCWithStaticMethods.convertInchesToFeet(inches);
       
        System.out.println(inches + " inches = " + feet + " feet.");

        System.out.print("Enter a measurement in feet: ");
        feet = keyboard.nextDouble();

        inches = DCWithStaticMethods.convertFeetToInches(feet);
        System.out.println(feet + " feet = " + inches + " inches.");
    }
    
    
}
