package _06_02_ClassDesign_CheckingAccount_02;

class CheckingAccount {

    // instance variables
    private String accountNumber;
    private String accountHolder;
    private double balance;

    
    //constructors
    CheckingAccount(String newAccountnumebr, String newHolder, double newBalance) {
        accountNumber = newAccountnumebr;
        accountHolder = newHolder;
        balance = newBalance;
    }
    
    CheckingAccount(double newBalance,String newAccountnumebr, String newHolder) {
        balance = newBalance;
        accountNumber = newAccountnumebr;
        accountHolder = newHolder;
    }
    
    CheckingAccount(String newAccountnumebr,double newBalance, String newHolder) {
        accountNumber = newAccountnumebr;
        balance = newBalance;
        accountHolder = newHolder;
    }

    // methods
    public double getBalance() {
        return balance;
    }

    public void processDeposit(int depositAmount) {
        balance = balance + depositAmount;
    }

    public void processCheck(int checkAmount) {
        int charge;
        if (balance < 100000) {
            charge = 15;
        } else {
            charge = 0;
        }

        balance = balance - checkAmount - charge;
    }

    public void display() {
        System.out.println(accountNumber + "\t" + accountHolder + "\t" + balance);
        System.out.println("");
    }

}

class CheckingAccountTester_02 {

    public static void main(String[] args) {

        CheckingAccount account1 = new CheckingAccount(450,"555-88-OD", "Diana");
        //CheckingAccount account2 = new CheckingAccount();
        CheckingAccount account3 = new CheckingAccount("55aaabbb22", "Nana", 888);


        account1.display();  
        //account2.display(); 
        account3.display();
        
        account1.processDeposit(2000);
        account1.processCheck(1500);
        //account1.balance = account1.balance - 500;
        account1.display();

    }
}
