package _06_06_objects_parameters;

class MyPoint {  
    public int x = 3, y = 5; // Change this to private to protect MyPoint obejects
    
    public void print() {
        System.out.println("x = " + x + "; y = " + y);
    }
}
class PointDoubler {
    public void twice(MyPoint parm) {

        System.out.println("Enter PointDoubler");
        parm.print();
        parm.x = parm.x * 2;
        parm.y = parm.y * 2;
        parm.print();
        System.out.println("Leave PointDoubler");
    }
}
class PointTester {
    public static void main(String[] args) {
        MyPoint pt = new MyPoint();
        PointDoubler dbl = new PointDoubler();     
        pt.print();
        dbl.twice(pt);
        pt.print();
    }
}
