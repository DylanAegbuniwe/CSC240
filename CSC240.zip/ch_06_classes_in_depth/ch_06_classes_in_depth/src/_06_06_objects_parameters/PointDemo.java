package _06_06_objects_parameters;

class ImmutablePoint {
    private int x, y;

    public ImmutablePoint(int px, int py) {
        x = px;
        y = py;
    }

    public void print() {
        System.out.println("x = " + x + "; y = " + y);
    }

}

class PointPrinter {
    public void print(ImmutablePoint p) {
        p.print(); //  call a public method
        //p.x = 77; // WRONG! can't do this 
    }
}

public class PointDemo {
    public static void main(String[] args) {
        ImmutablePoint tom = new ImmutablePoint(4, 8);
        tom.print(); // call a public method 
        //pt.x = 88;  // WRONG! can't do this
        PointPrinter jerry = new PointPrinter();
        jerry.print(tom); // this is fine, once the error in PointPrinter is fixed     
    }
}
