package _06_02_ClassDesign_CheckingAccount_04;

class CheckingAccount {

    // instance variables
    private final String accountNumber;
    private final String accountHolder;
    private double balance;
    private int useCount = 0;

    //constructors
    public CheckingAccount(String newAccountnumebr, String newHolder, double newBalance) {
        accountNumber = newAccountnumebr;
        accountHolder = newHolder;
        balance = newBalance;
    }

    // methods
    public double getBalance() {
        return balance;
    }

    public void processDeposit(int depositAmount) {
        balance = balance + depositAmount;
        incrementUse();

    }

    public void processCheck(int checkAmount) {
        int charge;
        if (balance < 100000) {
            charge = 15;
        } else {
            charge = 0;
        }

        balance = balance - checkAmount - charge;
        incrementUse();
    }

    // This method acts like a counter.
    // Other method will call it accordingly.
    private void incrementUse() {
        useCount = useCount + 1;
    }

    public void display() {
        System.out.println(accountNumber + "\t" + accountHolder + "\t" 
                + balance + "\tUse Count: " + useCount);
    }

    // need to be put inside a System.out.println statement.
    //@Override: Give credit to JVM for writing one for you
    @Override
    public String toString() {
        return "Account: " + accountNumber + "\tName: " + accountHolder
                + "\tBalance: " + balance + "\tUse Count: " + useCount;
    }
}

class CheckingAccountTester_04 {

    public static void main(String[] args) {
        CheckingAccount bobsAccount = new CheckingAccount("999", "Bob", 100);
        CheckingAccount jillsAccount = new CheckingAccount("111", "Jill", 500);

        bobsAccount.processCheck(50);
        System.out.println(bobsAccount.toString());

        jillsAccount.processDeposit(500);
        jillsAccount.processCheck(100);
        jillsAccount.processCheck(100);
        jillsAccount.processDeposit(100);

        jillsAccount.display();
    }
}
