package _06_03_constructors_overloading;

import java.util.Scanner;

/**
 * Revised class for basic pet data: name, age, and weight. Constructors and set
 * methods call a private method.
 */
class Pet2 {

    private String name;
    private int age;   //in years
    private double weight;//in pounds

    public Pet2(String initialName, int initialAge, double initialWeight) {
        verify(initialName, initialAge, initialWeight);
    }

    public Pet2(String initialName) {
        verify(initialName, 0, 0.0);
    }

    public Pet2(int initialAge) {
        verify("No name yet.", initialAge, 0.0);
    }

    public Pet2(double initialWeight) {
        verify("No name yet.", 0, initialWeight);
    }

    public Pet2() {
        verify("No name yet.", 0, 0.0);
    }

    private void verify(String newName, int newAge, double newWeight) {
        name = newName;
        if ((newAge < 0) || (newWeight < 0)) {
            System.out.println("Error: Negative age or weight.");
            System.exit(0);
        } else {
            age = newAge;
            weight = newWeight;
        }
    }

    private String getName() {
        return name;
    }

    private int getAge() {
        return age;
    }

    private double getWeight() {
        return weight;
    }

    public void readInputs() {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Please enter the correct pet name: ");
        name = keyboard.nextLine();

        System.out.print("Please enter the correct pet age: ");
        age = keyboard.nextInt();

        System.out.print("Please enter the correct pet weight: ");
        weight = keyboard.nextDouble();
    }

    public void writeOutput() {
        System.out.println("Name:   " + getName());
        System.out.println("Age:    " + getAge() + " years");
        System.out.println("Weight: " + getWeight() + " pounds");
        System.out.println("");
    }
}

public class Pet2Demo {

    public static void main(String[] args) {

//        Pet2 tom = new Pet2();
//        tom.writeOutput();
        

        // I need a name to create an object
//        Pet2 micky = new Pet2("Jane Doe");
//        micky.writeOutput();
//
//        // I need an age  to create an object
//        Pet2 leo = new Pet2(10);
//        leo.writeOutput();
//
//        // I need a weight to create an object
        Pet2 jerry = new Pet2(25.5);
        jerry.writeOutput();
//        
//         // I need a weight to create an object
        Pet2 mini = new Pet2("Mini",5,-15.2);
        mini.writeOutput();

    }
}
