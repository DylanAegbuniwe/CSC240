package _06_03_constructors_overloading;

import java.util.Scanner;

/**
 * Revised class for basic pet data: name, age, and weight. 
 * A constructor call another constructor.
 */
class Pet3 {

    private String name;
    private int age;   //in years
    private double weight;//in pounds

    public Pet3(String initialName, int initialAge,
            double initialWeight) {
        verify(initialName, initialAge, initialWeight);
    }

    public Pet3(String initialName) {
        this(initialName, 0, 0.0);
    }

    public Pet3(int initialAge) {
        this("No name yet.", initialAge, 0.0);
    }

    public Pet3(double initialWeight) {
        this("No name yet.", 0, initialWeight);
    }

    public Pet3() {
        this("No name yet.", 0, 0);
    }

    private void verify(String newName, int newAge,
            double newWeight) {
        name = newName;
        if ((newAge < 0) || (newWeight < 0)) {
            System.out.println("Error: Negative age or weight.");
            System.exit(0);
        } else {
            age = newAge;
            weight = newWeight;
        }
    }

    private String getName() {
        return name;
    }

    private int getAge() {
        return age;
    }

    private double getWeight() {
        return weight;
    }

    public void readInputs() {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Please enter the correct pet name: ");
        name = keyboard.nextLine();

        System.out.print("Please enter the correct pet age: ");
        age = keyboard.nextInt();

        System.out.print("Please enter the correct pet weight: ");
        weight = keyboard.nextDouble();
        
        verify(name,age,weight);
    }
    
    public void writeOutput() {
        System.out.println("Name:   " + getName());
        System.out.println("Age:    " + getAge() + " years");
        System.out.println("Weight: " + getWeight() + " pounds");
    }
}

public class Pet3Demo {

    public static void main(String[] args) {
        Pet3 yourPet = new Pet3("Jane Doe");
        System.out.println("My records on your pet are inaccurate.");
        System.out.println("Here is what they currently say:");
        yourPet.writeOutput();
        System.out.println("");
        yourPet.readInputs(); 
        System.out.println("");
        System.out.println("My updated records now say:");
        yourPet.writeOutput();
    }
}
