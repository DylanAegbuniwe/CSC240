package _06_03_constructors_overloading;

import java.util.Scanner;

/**
 * Class for basic pet data: name, age, and weight.
 */
// all metohds are public, we will change this on Pet2
class Pet1 {

    private String name;
    private int age;      //in years
    private double weight;//in pounds

    public Pet1() {
    }

    public Pet1(String initialName) {
        name = initialName;
        age = 1;
        weight = 10.0;
    }

    public Pet1(int initialAge) {
        name = "TBA";
        age = initialAge;
        weight = 0.0;
    }

    public Pet1(double initialWeight) {
        name = "No name yet";
        age = 0;
        weight = initialWeight;
    }

    public Pet1(int initialAge, double initialWeight) {
        name = "Danger";
        age = initialAge;
        weight = initialWeight;

    }

    public Pet1(double initialWeight, int initialAge) {
        name = "bullet";
        age = initialAge;
        weight = initialWeight;
    }

    public Pet1(String initialName, int initialAge, double initialWeight) {
        name = initialName;
        if ((initialAge < 0) || (initialWeight < 0)) {
            System.out.println("Error: Negative age or weight.");
            System.exit(0);
        } else {
            age = initialAge;
            weight = initialWeight;
        }
    }

    public void setPet(String newName, int newAge, double newWeight) {
        name = newName;
        if ((newAge < 0) || (newWeight < 0)) {
            System.out.println("Error: Negative age or weight.");
            System.exit(0);
        } else {
            age = newAge;
            weight = newWeight;
        }
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getWeight() {
        return weight;
    }

    public void readInputs() {
        Scanner keyboard = new Scanner(System.in);
        System.out.print("Please enter the correct pet name: ");
        name = keyboard.nextLine();

        System.out.print("Please enter the correct pet age: ");
        age = keyboard.nextInt();

        System.out.print("Please enter the correct pet weight: ");
        weight = keyboard.nextDouble();
    }

    public void writeOutput() {
        System.out.println("Name:   " + getName());
        System.out.println("Age:    " + getAge() + " years");
        System.out.println("Weight: " + getWeight() + " pounds");
        System.out.println("");
    }
}

public class Pet1Demo {

    public static void main(String[] args) {

        //not alloweed, since there is no default constructor
//        Pet1 tom = new Pet1();
//        tom.writeOutput();
        
//        Pet1 micky = new Pet1("Jane Doe");
//        micky.writeOutput();
//
//        Pet1 messi = new Pet1("Messi");
//        messi.writeOutput();
//
//        Pet1 leo = new Pet1(10);
//        leo.writeOutput();
//
//        Pet1 jerry = new Pet1(25.5,8);
//        jerry.writeOutput();
//
//        Pet1 maya = new Pet1(4, 35.5);
//        maya.writeOutput();
//
//        Pet1 bullet = new Pet1(8.5, 44, "Danger");
//        bullet.writeOutput();
//
        Pet1 spongebob = new Pet1("Meme", 4, 10.5);
        spongebob.writeOutput();
        spongebob.readInputs();
        spongebob.writeOutput();

// Constructors have to match inputs in terms of type and order
// You need to pass in the same exact type and order of arguments
// This is wrong, since there is no matching conctructor
//      Pet1 danger = new Pet1(8,"Danger",66.8);
//      danger.writeOutput();              
    }
}
