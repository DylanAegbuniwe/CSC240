package _06_07_objects_that_contains_objects;

class Car {

    // data
    private int startMiles;   // Starting odometer reading
    private int endMiles;     // Ending   odometer reading
    private double gallons;   // Gallons of gas used between the readings

    // constructor
    // if you declare it private, then there is no object initialization
    // try and check error messages
    Car(int first, int last, double gals) {
        startMiles = first;
        endMiles = last;
        gallons = gals;
    }

    // methods
    double calculateMPG() {
        return (endMiles - startMiles) / gallons;
    }

    void fillUp(int newOdo, double fillUpGals) {
        startMiles = endMiles;
        endMiles = newOdo;
        gallons = fillUpGals;
    }
}

class Fleet {

    // data
    private final Car town;
    private final Car suv;

    // constructor
    Fleet(int Car1StartOdo, int Car1EndOdo, double Car1Gallons,
            int Car2StartOdo, int Car2EndOdo, double Car2Gallons) {
        town = new Car(Car1StartOdo, Car1EndOdo, Car1Gallons);
        suv = new Car(Car2StartOdo, Car2EndOdo, Car2Gallons);
    }

    // method
    double calculateMPG() {
        double sumMPG;
        sumMPG = town.calculateMPG() + suv.calculateMPG();
        return sumMPG / 2.0;
    }

    void fillUp(int townOdo, double townGal, int suvOdo, double suvGal) {
        town.fillUp(townOdo, townGal);
        suv.fillUp(suvOdo, suvGal);
    }
}

class FleetTester {

    public static void main(String[] args) {
        Fleet myCars = new Fleet(1000, 1234, 10, 777, 999, 20);
        System.out.println("Fleet average MPG = " + myCars.calculateMPG());

        myCars.fillUp(1434, 10, 1099, 10);
        System.out.println("Fleet average MPG = " + myCars.calculateMPG());
    }
}
