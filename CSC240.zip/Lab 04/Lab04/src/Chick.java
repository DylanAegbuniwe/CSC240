/**
 *
 * Dylan Aegbuniwe, 11/4/19, Lab 04
 */
import java.util.*;

public class Chick implements Animal {
    private String myType;
    private String mySound;
    private int num;
    private boolean twoSound;
    private String sound;
    
    public Chick()
    {
        myType = "chick";
        mySound = "cheep";
               
    }
    public Chick(boolean two){
        if (two){
            myType = "Chick";
            Random chickCheck = new Random();
            num = chickCheck.nextInt(2)+1;
            if (num == 1){
              sound = "cheep";
            }
            if (num == 2){
              sound = "cluck";
              mySound = sound;
            }
            else if(!(two)){
                myType = "chick";
                mySound = "cheep";
            }
        }
    }
    @Override
    public String getSound()
    {
        return mySound;
    }
    @Override
    public String getType()
    {
        return myType;
    }
}
