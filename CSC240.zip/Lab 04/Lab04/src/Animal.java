/**
 *
 * Dylan Aegbuniwe, 11/4/19, Lab 04
 */
public interface Animal {
    public String getSound();
    public String getType();
}

