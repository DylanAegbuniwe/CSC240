/**
 *
 * Dylan Aegbuniwe, 11/4/19, Lab 04
 */
public class Dog implements Animal {
    private String myType;
    private String mySound;
    public Dog()
    {
        myType = "dog";
        mySound = "woof";
    }
    public String getSound()
    {
        return mySound;
    }
    public String getType()
    {
        return myType;
    }
    
}
