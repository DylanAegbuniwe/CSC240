/**
 *
 * Dylan Aegbuniwe, 11/4/19, Lab 04
 */
public class OldMacDonald {
    public static void main(String[] args){
        Farm f = new Farm();
        f.animalSounds();
    }
    
}
