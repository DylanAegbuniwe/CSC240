/**
 *
 * Dylan Aegbuniwe, 11/4/19, Lab 04
 */
public class NamedCow extends Cow implements Animal{

    private String name;
    private String myType;
    private String mySound;
    
    public NamedCow(String cowName){

        name = cowName;
        myType = "cow";
        mySound = "moo";
    }
    
    public String getName()
    {        
        return name;
    }
     public String getSound()
    {
        return mySound;
    }
    public String getType()
    {
        return myType;
    }
    
    
}
