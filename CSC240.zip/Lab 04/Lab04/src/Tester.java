/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author dylan
 */
public class Tester {
    public static void main(String[] args)
 {
 Cow c = new Cow();
 System.out.println( c.getType() + " goes " + c.getSound() );
 Dog d = new Dog();
 System.out.println( d.getType() + " goes " + d.getSound() );
 Chick ch = new Chick();
 System.out.println( ch.getType() + " goes " + ch.getSound() );
 }

    
}
