//HealthRecordDemo, first HW
package lab01;

import java.util.Scanner;
/**
 * Dylan Aegbuniwe, 9/8/2019, CSC240_Lab01: “Health Record Demo”
 */
public class HealthRecordDemo {


    public static void main(String[] args) {

        System.out.println("Hello! Please enter the following data: \n");
 
        HealthRecord newPatient = new HealthRecord();
        
        newPatient.readInputs();
        newPatient.display();
        
        System.out.println("Good bye!");
    }
    
}

class HealthRecord {
    
    private long ssn;
    private String firstName;
    private String lastName;
    private int age;
    private long phoneNumber;
    private String email;
    private double weight;
    private double height;
    
    public void readInputs() {
        
        setSSN();
        setFirstName();
        setLastName();
        setAge();
        setPhoneNumber();
        setEmail();
        setWeight();
        setHeight();
        
       
    }
    
    public void display() {
        System.out.println();
        System.out.println("\tSSN: " + getSSN());
        System.out.println("\tFirst Name: " + getFirstName());
        System.out.println("\tLast Name: " + getLastName());
        System.out.println("\tAge: " + getAge());
        System.out.println("\tPhone Number: " + getPhoneNumber());
        System.out.println("\tEmail: " + getEmail());
        System.out.println("\tWeight: " + getWeight());
        System.out.println("\tHeight: " + getHeight());
        System.out.println("\tBMI: " + calculateBMI());
    }
    
    private void setSSN() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter your SSN. It must be a number between 000000001 and 999999999.");
        ssn = keyboard.nextLong();
        
        if (ssn < 000000001 || ssn > 999999999) {
            System.out.println("Invalid input.");
            System.exit(0);
        } 
        
    }
    
    private void setFirstName() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter your first name.");
        firstName = keyboard.next();
        
        } 
    
    private void setLastName() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter your last name.");
        lastName = keyboard.next();
        
        }  
    
    private void setAge() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter your age. It must be a number between 1 and 125.");
        age = keyboard.nextInt();
        
        if (age <= 0 || age > 125) {
            System.out.println("Invalid input.");
            System.exit(0);
        } 
    }
     
    private void setPhoneNumber() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter your phone #. It must be a number between 0000000001 and 9999999999.");
        phoneNumber = keyboard.nextLong();
        
        if (phoneNumber < 0000000001 || phoneNumber > 9999999999L) {
            System.out.println("Invalid input.");
            System.exit(0);
        } 
      }
        
    private void setEmail() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter your email");
        email = keyboard.next();
        
      }
      
    private void setWeight() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter your weight (lbs). It must be a number between 1 and 1400.");
        weight = keyboard.nextInt();
        
        if (weight <= 0 || weight > 1400) {
            System.out.println("Invalid input.");
            System.exit(0);
        } 
      }
      
    private void setHeight() {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter your height (inches). It must be a number between 1 and 108.");
        height = keyboard.nextInt();
        
        if (height <= 0 || height > 108) {
            System.out.println("Invalid input.");
            System.exit(0);
        } 
    }
    
    private long getSSN(){
        return ssn;
    }
    
    private String getFirstName(){
        return firstName;
    }
    
    private String getLastName(){
        return lastName;
    }
    
    private int getAge(){
        return age;
    }
    
    private long getPhoneNumber(){
        return phoneNumber;
    }
    
    private String getEmail(){
        return email;
    }
    
    private double getWeight(){
        return weight;
    }
    
    private double getHeight(){
        return height;
    }
    
    private double calculateBMI() {
        double BMI = (weight / (height * height) * 703);
        return BMI;
    
    
}
    
    
     
      
    
      
}
