
package _09_02_more_about_exceptions;

import java.io.IOException;

public class MultipleThrows
{
  public static void methodC() throws IOException
  {
     // Some I/O statements
  }

  public static void methodB() throws IOException
  {
     methodC();
  }

  public static void methodA() throws IOException
  {
     methodB();
  }

  public static void main ( String[] a ) throws IOException
  {
     methodA();
  }
}
