package _09_02_more_about_exceptions;

import java.io.IOException;

public class MultipleThrows_II {

    public static void methodC() throws IOException {
        // Some I/O statements
    }

    public static void methodB() throws IOException {
        methodC();
    }

    public static void methodA() {
        try {
            methodB();
        } catch (IOException ex) {
            // statements to handle the exception
        }
    }

    public static void main(String[] a) {
        methodA();
    }
}
