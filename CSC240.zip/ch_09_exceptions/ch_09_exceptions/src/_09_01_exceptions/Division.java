package _09_01_exceptions;

import java.util.*;

public class Division {

    public static void main(String[] a) {
        Scanner scan = new Scanner(System.in);
        int num = 0, div = 0;

        try {
            System.out.print("Enter the numerator: ");
            num = scan.nextInt();
            System.out.print("Enter the divisor  : ");
            div = scan.nextInt();
            System.out.println(num + " / " + div + " is " + (num / div) + " rem " + (num % div));
        } catch (InputMismatchException ex) {
            System.out.println("You entered bad data.");
            System.out.println("Run the program again.");
        } catch (ArithmeticException ex) {
            System.out.println("You can't divide " + num + " by " + div);
        }
    }
}
