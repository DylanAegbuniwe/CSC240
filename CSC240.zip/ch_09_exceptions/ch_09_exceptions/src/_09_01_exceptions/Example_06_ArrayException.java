package _09_01_exceptions;

public class Example_06_ArrayException {

    public static void main(String[] args) {
        int[] data = {3, 2, -3, 5};
        int sum = 0;
        double avg = 0;

        try {
            for (int j = 0; j <= 4; j++) {
                sum += data[j];
            }
            avg = sum / 0;
        } catch (ArrayIndexOutOfBoundsException ex) {
            System.out.println("Off by one.");
        } catch (RuntimeException ex) {
            System.out.println("Runtime Problem.");
        } catch (Exception ex) {
            System.out.println("Exception");
        }
        System.out.println("sum is " + sum);

    } // end of main
} // end of class
