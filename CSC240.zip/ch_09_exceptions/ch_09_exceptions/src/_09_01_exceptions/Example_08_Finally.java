package _09_01_exceptions;

import java.util.*;

// Runt three cases
// 1. If the user enters good data
// 2. If the user enters a zero divisor
// 3. If the user enters bad data


public class Example_08_Finally {

    public static void main(String[] a) {
        Scanner scan = new Scanner(System.in);
        int num = 0, div = 0;

        try {
            System.out.print("Enter the numerator: ");
            num = scan.nextInt();
            System.out.print("Enter the divisor  : ");
            div = scan.nextInt();
            System.out.println(num + " / " + div + " is " + (num / div) + " rem " + (num % div));
        } catch (ArithmeticException ex) {
            System.out.println("You can't divide " + num + " by " + div);
        } finally {
            System.out.println("The program is now ending.");
        }
        System.out.println("Good-bye");
    }
}
