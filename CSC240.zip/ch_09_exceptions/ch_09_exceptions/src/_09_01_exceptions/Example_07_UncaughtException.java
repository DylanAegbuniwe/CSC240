package _09_01_exceptions;

import java.util.Scanner;


// Will the sentence "The program is now ending" be printed 
// when bad data is entered?


public class Example_07_UncaughtException {

    public static void main(String[] a) {
        Scanner scan = new Scanner(System.in);
        int num = 0, div = 0;

        try {
            System.out.print("Enter the numerator: ");
            num = scan.nextInt();
            System.out.print("Enter the divisor  : ");
            div = scan.nextInt();
            System.out.println(num + " / " + div + " is " + (num / div) + " rem " + (num % div));
        } catch (ArithmeticException ex) {
            System.out.println("You can't divide " + num + " by " + div);
        }

        System.out.println("The program is now ending.");
    }
}
