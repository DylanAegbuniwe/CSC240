package _09_01_exceptions;

import java.util.Scanner;

public class Example_01_Square {

    public static void main(String[] a) {
        Scanner scan = new Scanner(System.in);
        int num;

        System.out.print("Enter an integer: ");
        num = scan.nextInt();
        System.out.println("The square of " + num + " is " + num * num);
    }
}
