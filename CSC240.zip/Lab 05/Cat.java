/**
 *
 * @author dylan
 */
public class Cat extends Animal implements Pet {
    private String catName;
    
    public Cat(){
        this("");
    }
    public Cat(String name)
    {
        super(4);
        catName=name;}
//@Override
    public void eat() 
    {
        System.out.println("Cats eat catfood.");
    }
    
    public void play() 
    {
        throw new UnsupportedOperationException("Not supported yet.");
    }

     public void setName(String name) 
    {
        catName = name;
    }
     
     public String getName() 
    {
        return catName;
    }
}
