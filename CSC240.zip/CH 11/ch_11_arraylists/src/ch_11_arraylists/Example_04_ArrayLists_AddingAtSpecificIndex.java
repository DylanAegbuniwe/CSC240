package ch_11_arraylists;

import java.util.*;

public class Example_04_ArrayLists_AddingAtSpecificIndex {

    public static void main(String[] args) {
        ArrayList<String> names = new ArrayList<String>();

        names.add("Amy");
        names.add("Bob");
        names.add("Chris");

        // Print original arrangement
        System.out.println("Before adding at index 1:");
        for (int j = 0; j < names.size(); j++) {
            System.out.println(j + ": " + names.get(j));
        }

        // Insert an element
        names.add(1, "Valerie");

        // Print new arrangement
        System.out.println("\nAfter adding at index 1:");
        for (int j = 0; j < names.size(); j++) {
            System.out.println(j + ": " + names.get(j));
        }

        // Would the following statement work in the above program?
        //names.add(5, "Gertrude");
    }
}
