package ch_11_arraylists;

// Automatic Bxoing vs Unboxing
import java.util.*;

public class Example_10_ArraysLists_WrapperClasses {

    public static void main(String[] args) {
        ArrayList<Integer> data = new ArrayList<Integer>();

        data.add(new Integer(1));
        data.add(new Integer(3));
        data.add(new Integer(17));
        data.add(new Integer(29));

        for (Integer val : data) {
            System.out.print(val + " ");
        }

        System.out.println();
    }
}
