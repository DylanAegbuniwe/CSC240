package ch_11_arraylists;

import java.util.*;


/*
To check if an ArrayList has elements use
boolean isEmpty()
which returns true if the cells of the ArrayList are all empty.

Warning:The value null in a cell counts as data. An empty cell is not the same as a cell that contains null.

To remove all elements from a list, use
void clear()
 */
public class Example_06_ArrayLists_IsEmpty {

    public static void main(String[] args) {
        ArrayList<String> nobby = new ArrayList<String>();

        System.out.println("Case A:" + nobby.isEmpty());

        nobby.add(null);
        System.out.println("Case B:" + nobby.isEmpty());

        nobby.remove(0);
        System.out.println("Case C:" + nobby.isEmpty());

        nobby.add("");
        System.out.println("Case D:" + nobby.isEmpty());

        nobby.clear();
        System.out.println("Case E:" + nobby.isEmpty());

    }
}
