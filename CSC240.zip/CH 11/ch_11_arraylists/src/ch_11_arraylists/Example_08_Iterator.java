package ch_11_arraylists;

import java.util.*;

public class Example_08_Iterator {

    public static void main(String[] args) {
        // Create and populate the list
        ArrayList<String> names = new ArrayList<String>();
        names.add("Amy");
        names.add("Bob");
        names.add("Chris");
        names.add("Deb");
        names.add("Elaine");
        names.add("Frank");
        names.add("Gail");
        names.add("Hal");

        // Create an iterator for the list
        // ArrayList implements the Iterable interface. 
        // iterator() is the only method in this interface.
        Iterator<String> iter = names.iterator();

        // Note: An iterator implements the Iterator<E> interface
        // Navigate to Iterator source to see it.
        // Use the iterator to visit each element
        while (iter.hasNext()) {
            System.out.println(iter.next());
        }

    }
}
