package ch_11_arraylists;

import java.util.* ;

public class Example_07_ArrayLists_SearchingElements
{
  public static void main ( String[] args)
  {
    ArrayList<String> names = new ArrayList<String>();

    names.add( "Amy" );     
    names.add( "Bob" );
    names.add( "Chris" );   
    names.add( "Deb" );
    names.add( "Elaine" );  
    names.add( "Joe" );

    System.out.println( "First Search: " + names.indexOf( "Elaine" ) ); 
    System.out.println( "Secnd Search: " + names.indexOf( "Zoe" ) ); 
  }
}