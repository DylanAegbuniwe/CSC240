
package Lab_03;

/**
 *
 * @author Dylan Aegbuniwe, 10/25/19, Lab 03
 */
public class Book {
    private String title;
    private int numOfPages;
    private double price;
    private int quantity;
    
    public Book(String theTitle, int pages, double cost, int num){
        title = theTitle;
        numOfPages = pages;
        price = cost;
        quantity = num;
    }
    
    public String getTitle(){
        return title;
    }
    
    public double getPrice(){
        return price;
    }
    
    public int getQuantity(){
       return quantity; 
    }
    
    public String toString(){
        return "Book Title: "+title +"\nNumber of Pages: "+numOfPages + "\nPrice: "+price +"\nQuantity of book: "+quantity+"\n";
    }
    
    public void subtractQuantity(int amount){
        quantity = quantity - amount;
        if (quantity - amount < 0)
                quantity = 0;
    }
    
    public void addQuantity(int amount){
        quantity = quantity + amount;
        
    }
    
}
