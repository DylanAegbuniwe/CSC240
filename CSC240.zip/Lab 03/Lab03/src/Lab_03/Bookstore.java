package Lab_03;

/**
 *
 * @author Dylan Aegbuniwe, 10/25/19, Lab 03
 */
public class Bookstore {

    private final Book[] books;
    private int totalbooks;
    private double gross;
    private final static int MAXNUMOFBOOKS = 1000;

    public Bookstore() {  
	books = new Book[MAXNUMOFBOOKS];
        totalbooks = 0;
        gross = 0.0;
        
    }

    public void addNewBook(Book b) {     
	if (totalbooks < books.length){
            books[totalbooks] = b;
            totalbooks++;     
        }
        else
            System.out.println("Error, book not found!");
            
    }

    public void addBookQuantity(String title, int quantity) {
        for (int i=0; i<totalbooks; i++){
            if (title.equals(books[i].getTitle()))
                books[i].addQuantity(quantity);
            else
                System.out.println("Error, book not found!");
        }
    }


    public boolean inStock(String title, int quantity) {
        for (int i=0; i<totalbooks; i++){
            if(title.equals(books[i].getTitle())){
                if(quantity <= (books[i].getQuantity())) {return true;}
            }
            else {return false;}    
        }
            return false;
    }


    public boolean sellBook(String title, int quantity) {
            for (int i=0; i<totalbooks; i++){
                if(books[i].getTitle().equals(title)){
                    if(books[i].getQuantity() >= quantity){
                        books[i].subtractQuantity(quantity);
                        gross += (quantity*books[i].getPrice());
                        return true;
                    } 
                }
            }
        return false;
    }


    public void listBooks() {	
	for (int i=0; i<totalbooks; i++){
            System.out.println((books[i].toString()));
        }
    }


    public void listTitles() {
        for (int i=0; i<totalbooks; i++){
            System.out.println((books[i].getTitle()));
        }
    }


    public double getIncome() {	
        return gross;
    }
}

