package Lab_03;
import java.util.Scanner;

/**
 *
 * @author Dylan Aegbuniwe, 10/25/19, Lab 03
 */
public class BookstoreDemo {
    
    public static void main(String[] args){
        Bookstore bookstore = new Bookstore();
        Scanner input = new Scanner(System.in);//User input
        Scanner input2 = new Scanner(System.in); //Menu input
        int choice = 0;
        int quant = 0;
        int page = 0;
        double cost = 0.0;
        String title;
        boolean End = false;
        boolean check = false;
        boolean inCheck = false;
        
        System.out.println("Welcome to WCU Bookstore!");
        
        //menu
        System.out.println("=============================================");
        do{
            System.out.println("What would you like to do?\n");
            System.out.println("1. Add a book to the stock.");
            System.out.println("2. Sell a book in the stock.");
            System.out.println("3. List the titles of all books in stock.");
            System.out.println("4. List all info of the books in stock.");
            System.out.println("5. Print out the bookstore's gross income.");
            System.out.println("6. Quit.");
            
            while(!(check)){ //Verify the user's input, check for false inputs
            System.out.println("Please enter a number from 1-6.");
            if(input2.hasNextInt()){
                choice = input2.nextInt();
                check = true;
            }
            else{
                check = false;
                input2.next();
                System.out.println("\nError! Please enter a number from 1-6");     
            }
            }
            
            check = false;        
                 
            switch(choice){
                case 1: //Adding a book.
                    System.out.println("What is the name of the book?");
                    title = input.nextLine();
                    while (title.equals("")){
                        System.out.println("Error! Please enter a title.");
                        title = input.nextLine();
                    }
                    if(bookstore.inStock(title, quant)){
                        System.out.println("This book is already in stock. Adding to the book quantity.");//get ready to add quantity
                        while(!(inCheck)){
                            System.out.println("\nHow many copies would you like to add?");
                            if(input.hasNextInt()){
                                quant = input.nextInt();
                                while (quant <=0){
                                    System.out.println("Error! Please enter a positive number in numerical form.");
                                    quant = input.nextInt();
                                }
                                inCheck = true;
                            }
                            else{
                                System.out.println("Error! Please enter a positive number in numerical form.");
                            }
                        }
                            inCheck = false;
                            
                            bookstore.addBookQuantity(title, quant);
                            System.out.println("\nThe book(s) has been added!");
                    }
                    else if(!(bookstore.inStock(title, quant))){
                        System.out.println("\nWe do not have that book in our stock. Adding new book.");
                        while(!(inCheck)){
                            System.out.println("\nPlease enter the number of pages.");
                            if(input.hasNextInt()){
                                page = input.nextInt();
                                while (page <=0){
                                    System.out.println("Error! Please enter a whole, positive number in numerical form.");
                                    page = input.nextInt();
                                }
                                inCheck = true;
                            }
                            else{
                                inCheck = false;
                                input.next();
                                System.out.println("Error! Please enter a whole, positive number in numerical form.");
                            }
                        }
                        inCheck = false;
                        while(!(inCheck)){
                            System.out.println("\nHow many copies are you storing?");
                            if(input.hasNextInt()){
                                quant = input.nextInt();
                                while (quant <=0){
                                    System.out.println("Error! Please enter a whole, positive number in numerical form.");
                                    quant = input.nextInt();
                                }
                                inCheck = true;
                            }
                            else{
                                inCheck = false;
                                input.next();
                                System.out.println("Error! Please enter a whole, positive number in numerical form.");
                            }
                        }
                        inCheck = false;
                        while(!(inCheck)){
                            System.out.println("\nWhat is the price of the book?");
                            if(input.hasNextDouble()){
                                cost = input.nextDouble();
                                while (cost <=0){
                                    System.out.println("Error! Please enter a positive number in numerical form.");
                                    cost = input.nextDouble();
                                }
                                inCheck = true;
                            }
                            else{
                                inCheck = false;
                                input.next();
                                System.out.println("Error! Please enter a number in numerical form.");
                            }
                        }
                        inCheck = false;
                        
                        Book book = new Book(title,page,cost,quant);
                        bookstore.addNewBook(book);
                        System.out.println("The book has been added to the stock!\n");
                    }
                    input.nextLine();
                    System.out.println("=============================================");
                    check = false;
                    break;
                
                case 2://Sell books.
                    System.out.println("\nPlease enter the name of the book you want to sell.");
                    title = input.nextLine();
                    if(!(bookstore.inStock(title, quant))){
                        System.out.println("Sorry, we do not have this book.");    
                    }
                    else{
                        while(!(inCheck)){
                            System.out.println("How many books do you want to sell?");
                            if(input.hasNextInt()){
                                quant = input.nextInt();
                                while (quant <=0){
                                    System.out.println("Error! Please enter a positive number in numerical form.");
                                    quant = input.nextInt();
                                }
                                inCheck = true;
                            }
                            else{
                                inCheck = false;
                                input.next();
                                System.out.println("Error! Please enter a positive number in numerical form.");
                            }
                        }
                        inCheck = false;
                        if (bookstore.inStock(title, quant)){
                            bookstore.sellBook(title, quant);
                            System.out.println(quant+" copies of "+title+" have been sold!");
                        }
                        else if (!(bookstore.inStock(title, quant))) //No sale
                            System.out.println("The sale failed.");
                        
                    }
                    System.out.println();
                    System.out.println("=============================================");
                    check = false;
                    break;
                    
                case 3: //Book titles.
                    System.out.println();
                    bookstore.listTitles();
                    System.out.println();
                    System.out.println("=============================================");
                    break;
                    
                case 4: //All book info.
                    System.out.println();
                    bookstore.listBooks();
                    System.out.println();
                    System.out.println("=============================================");
                    check = false;
                    break;
                    
                case 5: //Total income.
                    System.out.println("The store has made $"+bookstore.getIncome()+" this session.");
                    System.out.println();
                    System.out.println("=============================================");
                    check = false;
                    break;
                    
                case 6: //End
                    System.out.println("Thank you for using our bookstore! Please come again!");
                    End = true;
                    break;
                    }   
                    }
        while(!End);
        }          
    }
    
