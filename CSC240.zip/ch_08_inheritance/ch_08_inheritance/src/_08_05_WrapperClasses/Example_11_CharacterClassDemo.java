package _08_05_WrapperClasses;

public class Example_11_CharacterClassDemo {

    public static void main(String args[]) {

        System.out.println(Character.isLetter('c'));
        System.out.println(Character.isLetter('5'));
        System.out.println("********************\n");

        System.out.println(Character.isDigit('.'));
        System.out.println(Character.isDigit('5'));
        System.out.println("********************\n");

        System.out.println(Character.isWhitespace('c'));
        System.out.println(Character.isWhitespace(' '));
        System.out.println(Character.isWhitespace('\n'));
        System.out.println(Character.isWhitespace('\t'));
        System.out.println("********************\n");

        System.out.println(Character.isUpperCase('c'));
        System.out.println(Character.isUpperCase('C'));
        System.out.println(Character.isUpperCase('\n'));
        System.out.println(Character.isUpperCase('\t'));
        System.out.println("********************\n");

        System.out.println(Character.isLowerCase('c'));
        System.out.println(Character.isLowerCase('C'));
        System.out.println(Character.isLowerCase('\n'));
        System.out.println(Character.isLowerCase('\t'));
        System.out.println("********************\n");

        System.out.println(Character.toUpperCase('8'));
        System.out.println(Character.toUpperCase('C'));
        System.out.println("********************\n");

        System.out.println(Character.toLowerCase('c'));
        System.out.println(Character.toLowerCase('C'));
        System.out.println("********************\n");

        System.out.println(Character.toString('c'));
        System.out.println(Character.toString('C'));
        System.out.println("********************\n");

    }
}
