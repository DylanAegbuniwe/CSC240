package _08_05_WrapperClasses;

// By default we get these wrapping services
//import java.lang.Package;
// no need for that import java.lang.Package;

/*
 * As the name says, a wrapper class wraps (encloses) around a data type
 * and gives it an object appearance.
 * /

 /*
 * The primitive data types are not objects; they do not belong to any class;
 * they are defined in the language itself. Sometimes,
 * it is required to convert data types into objects in Java language.
 * For example, upto JDK1.4, the data structures accept only objects to store.
 * A data type is to be converted into an object and then added to a Collection
 * Stack or Vector etc. For this conversion, the designers introduced wrapper classes.
 */
public class WrappingUnWrapping {

    public static void main(String args[]) {
        // Data types
        byte grade = 2;
        short counter = 3;
        char choice = 'a';
        int marks = 50;
        float price = 8.6f; // observe a suffix of f for float
        double rate = 50.5d;
        long population = 333444555;

        // Wrapping: data types to objects
        Byte wrappedByte = new Byte(grade);
        Short wrappedShort = new Short(counter);
        Character wrappedChar = new Character(choice);
        Integer wrappedInteger = new Integer(marks);

        Float wrappedFloat = new Float(price);
        Long wrappedLong = new Long(population);
        Double wrappedDouble = new Double(rate);

        // Wrapper classes have no default constructor
        //Integer m2 = new Integer();

        // Print the values from objects
        System.out.println("Values of Wrapper objects (printing as objects)");
        System.out.println("Byte object wrappedByte         :  " + wrappedByte);
        System.out.println("Short object wrappedShort       :  " + wrappedShort);
        System.out.println("Character object wrappedChar    :  " + wrappedChar);
        System.out.println("Integer object wrappedInteger   :  " + wrappedInteger);
        System.out.println("Float object wrappedFloat       :  " + wrappedFloat);
        System.out.println("Double object wrappedDouble     :  " + wrappedDouble);
        System.out.println("Long object wrappedLong         :  " + wrappedLong);
        System.out.println();


        // MAX_VALUE and MIN_VALUE
        System.out.println("The maximum value of byte     : " + Byte.MAX_VALUE);
        System.out.println("The minimum value of byte     : " + Byte.MIN_VALUE);

        System.out.println("The maximum value of short    : " + Short.MAX_VALUE);
        System.out.println("The minimum value of short    : " + Short.MIN_VALUE);

        System.out.println("The maximum value of char     : " + Character.MAX_VALUE);
        System.out.println("The minimum value of char     : " + Character.MIN_VALUE);

        System.out.println("The maximum value of integer  : " + Integer.MAX_VALUE);
        System.out.println("The minimum value of integer  : " + Integer.MIN_VALUE);

        System.out.println("The maximum value of float    : " + Float.MAX_VALUE);
        System.out.println("The minimum value of float    : " + Float.MIN_VALUE);

        System.out.println("The maximum value of long     : " + Long.MAX_VALUE);
        System.out.println("The minimum value of long     : " + Long.MIN_VALUE);

        System.out.println("The maximum value of double   : " + Double.MAX_VALUE);
        System.out.println("The minimum value of double   : " + Double.MIN_VALUE);
        System.out.println();

        // UnWrapping: objects to data types
        byte tom = wrappedByte.byteValue();
        short objectShort = wrappedShort.shortValue();
        char objectCharacter = wrappedChar.charValue();
        int objectInteger = wrappedInteger;
        float objectFloat = wrappedFloat.floatValue();
        double jerry = wrappedDouble.doubleValue();
        long objectLong = wrappedLong.longValue();

        // Print the values from data types
        System.out.println("Unwrapped   values (printing as data types)");
        System.out.println("The byte    value of wrappedByte     : " + tom);
        System.out.println("The short   value of wrappedShort    : " + objectShort);
        System.out.println("The char    value of wrappedChar     : " + objectCharacter);
        System.out.println("The integer value of wrappedInteger  : " + objectInteger);
        System.out.println("The float   value of wrappedFloat    : " + objectFloat);
        System.out.println("The double  value of wrappedDouble   : " + jerry);
        System.out.println("The long    value of wrappedLong     : " + objectLong);

    }
}
