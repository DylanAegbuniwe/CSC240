package _08_01_inheritance;

class Video {
    String title;    // name of the i_ tem
    int length;   // number of minutes
    boolean avail;    // is the video in the store?
    double rent;

    // constructor
    public Video(String ttl, int lngth, double rt) {

        title = ttl;
        length = lngth;
        avail = true;
        rent = rt;
    }

    public void show() {
        System.out.println(title + ", " + length + " min. available:" + avail);
    }
}

class Movie extends Video {
    String director;     // name of the director
    String rating;       // G, PG, R, or X

    // constructor
    public Movie(String ttl, int lngth, String dir, String rtng, double rt) {
        super(ttl, lngth, rt);   // use the super class's constructor
        director = dir;
        rating = rtng;      // initialize what's new to Movie
    }

    @Override
    public void show() {
        super.show();
        System.out.println("dir: " + director + "  " + rating);
    }
}

class MusicVideo extends Video {
    String artist;
    String category;

    // constructor
    public MusicVideo(String ttl, int len, String art, String cat, double rt) {
        super(ttl, len, rt);
        artist = art;
        category = cat;
    }

    @Override
    public void show() {
        super.show();
        System.out.println("artist:" + artist + " style: " + category);
    }
}

public class VideoStore {

    public static void main(String args[]) {
        Video item1 = new Video("Microcosmos", 90, 9.99);
        Movie item2 = new Movie("Jaws", 120, "Spielberg", "PG", 12.99);
        MusicVideo item3 = new MusicVideo("They Don't Care About Us", 5, "Michael Jackson", "Pop", 0.99);

        item1.show();
        item2.show();
        item3.show();
    }
}
