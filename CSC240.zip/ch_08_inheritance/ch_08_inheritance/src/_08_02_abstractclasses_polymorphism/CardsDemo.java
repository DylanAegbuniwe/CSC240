package _08_02_abstractclasses_polymorphism;

abstract class Card {

    String recipient;

    public abstract void greeting();
    
    public  void display (){
        System.out.println("*************");
        
    }
}

class Holiday extends Card {

    public Holiday(String r) {
        recipient = r;
    }

    @Override
    public void greeting() {
        System.out.println("\nDear " + recipient + ",");
        System.out.println("Season's Greetings!\n");
    }

    @Override
    public void display (){
        System.out.println("^^^^^^^^^^^^^^^^^^^^^^^^");
    }
    
}

class Birthday extends Card {

    private final int age;

    public Birthday(String r, int years) {
        recipient = r;
        age = years;
    }

    @Override
    public void greeting() {
        System.out.println("\nDear " + recipient + ",");
        System.out.println("Happy " + age + "th Birthday");
    }
}

class Valentine extends Card {

    private final int kisses;

    public Valentine(String r, int k) {
        recipient = r;
        kisses = k;
    }

    @Override
    public void greeting() {
        System.out.println("\nDear " + recipient + ",");
        System.out.println("Love and Kisses,");

        for (int j = 0; j < kisses; j++) {
            System.out.print("<3 ");
        }
        System.out.println("\n");
    }
}

class YouthBirthday extends Birthday {

    public YouthBirthday(String r, int years) {
        super(r, years);
    }

    @Override
    public void greeting() {
        super.greeting();
        System.out.println("How you have grown!!\n");
    }

    // additional method---does not override parent's method
    public void greeting(String sender) {
        super.greeting();
        System.out.println("How you have grown!!");
        System.out.println("Love, " + sender + "\n");
    }

}
class AdultBirthday extends Birthday {

    public AdultBirthday(String r, int years) {
        super(r, years);
    }

    @Override
    public void greeting() {
        super.greeting();
        System.out.println("You haven't changed at all!!!\n");
    }
}
public class CardsDemo {

    public static void main(String[] args) {

//        // NO objects based on an abstract class
//        Card abc = new Card ();
//        Holiday hol = new Holiday("Dad");
//        hol.greeting();
//
//        Birthday brth = new Birthday("Lolo", 35);
//        brth.greeting();
////
//        Valentine val = new Valentine("Diana", 25);
//        val.greeting();
////
//
//        
//        // Polymorphism
//        Card myCard = new Birthday("John", 55);
//       myCard.greeting();
////
//        Card myCard2 = new Holiday("Dad");
//        myCard2.greeting();
////
//        Card myCard3 = new Valentine("Diana", 25);
//        myCard3.greeting();
////        
////        
//        // Incomaptible types, Birthday can not be converted to Holiday
//        Birthday brthHol = new Holiday("Mom");
//        brthHol.greeting();
//        
//        
//        YouthBirthday yb = new YouthBirthday("Sophia", 7);
//        yb.greeting();
//        yb.greeting("Alice");
//        
//        YouthBirthday mini = new Birthday("Sophia", 7);
//        mini.greeting();
//        mini.greeting("mini");
//
//        AdultBirthday ab = new AdultBirthday("Barney", 29);
//       ab.greeting();
//
//        // Using an array to print many cards
        Card[] cards = new Card[12];

        cards[0] = new YouthBirthday("Valerie", 7);
        cards[1] = new AdultBirthday("Walter", 47);
        cards[2] = new Birthday("Zoe", 30);
        cards[3] = new Holiday("Kelly");
        cards[4] = new Valentine("Diana", 22);

        for (int j = 0; j <= 4; j++) {
            cards[j].greeting();
        }

    } // end of main
} // end of class
