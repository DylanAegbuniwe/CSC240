package _08_06_ComparabelInterface;

import java.util.Arrays;

public class Example_03_SortingArrayofStrings {

    public static void main(String[] args) {
        String[] animals = {"bat", "fox", "gnu", "eel", "ant", "dog", "fox", "tiger"};

        System.out.print("Scrambled array:  ");
        for (String anm : animals) {
            System.out.print(anm + " ");
        }

        System.out.println();

        Arrays.sort(animals);

        System.out.print("Sorted    array:  ");
        for (String anm : animals) {
            System.out.print(anm + " ");
        }

        System.out.println();

    }
}
