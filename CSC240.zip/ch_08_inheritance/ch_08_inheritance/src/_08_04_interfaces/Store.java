package _08_04_interfaces;

interface Taxable {

    public static final double taxRate = 0.06;

    public double calculateTax();
}

class Goods {

    String description;
    double price;

    Goods(String des, double pr) {
        description = des;
        price = pr;
    }

    void display() {
        System.out.println("\nitem: " + description + " \nprice: " + price);
    }
}

class Food extends Goods {

    double calories;

    Food(String des, double pr, double cal) {
        super(des, pr);
        calories = cal;
    }

    @Override
    void display() {
        super.display();
        System.out.println("calories: " + calories);
    }
}

class Toy extends Goods implements Taxable {

    int minimumAge;

    Toy(String des, double pr, int min) {
        super(des, pr);
        minimumAge = min;
    }

    @Override
    void display() {
        super.display();
        System.out.println("minimum age: " + minimumAge);
    }

    @Override
    public double calculateTax() {
        return price * taxRate;
    }
}

class Book extends Goods implements Taxable {

    String author;

    Book(String des, double pr, String auth) {
        super(des, pr);
        author = auth;
    }

    @Override
    void display() {
        super.display();
        System.out.println("author: " + author);
    }

    @Override
    public double calculateTax() {
        return price * taxRate;
    }
}

public class Store {

    public static void main(String[] args) {
        Goods gd = new Goods("bubble bath", 1.40);
        Food fd = new Food("ox tails", 4.45, 1500);
        Book bk = new Book("Emma", 24.95, "Austen");
        Toy ty = new Toy("Legos", 54.45, 8);

        gd.display();

        fd.display();

        ty.display();
        System.out.println("Tax is: " + ty.calculateTax() + "\n");

        bk.display();
        System.out.println("Tax is: " + bk.calculateTax() + "\n");

    }
}
