/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg3hranomdizer;

/**
 *
 * @author dylan
 */

import java.util.Random;

public class Main {
    public static void main(String[] args){
        Random firstGoal = new Random();
        Random secondGoal = new Random();
        
        String goals[] = {"Sword" , "Lance" , "Axe" , "Bow" , "Brawling" , "Reason" , "Faith" , "Authority" , "Heavy Armor" , "Riding" , "Flying"};
        
        System.out.print("Claude: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Lorenz: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Raphael: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Ignatz: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Hilda: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Marianne: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Leonie: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Lysithea: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Dorothea: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Petra: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Bernadetta: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Caspar: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Linhardt: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Ferdinand: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Sylvain: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Felix: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Ashe: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Mercedes: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Annette: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Ingrid: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Seteth: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Flayn: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Hanneman: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Manuela: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Alois: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Catherine: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Shamir: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
         System.out.print("Cyril: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
        System.out.print("Byleth: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
        System.out.print("Edelgard: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
        System.out.print("Hubert: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
        System.out.print("Dimitri: " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
        System.out.print("Dedueaalso : " + goals[new Random().nextInt (goals.length)]);
        System.out.println(" + " + goals[new Random().nextInt (goals.length)]);
        
        
        
        
    }
    
}
