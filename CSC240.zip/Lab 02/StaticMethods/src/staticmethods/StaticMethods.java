package staticmethods;

/*
Dylan Aegbuniwe, CSC 240_01 Lab 02, 9/30/19
*/

import java.util.Random;

class StaticMetohdsDemo {

    // Marco for counting the methods
    static int N = 1;

    public static void main(String[] args) {
        spacer();
        System.out.println(countsGuests("Jason", 3));
        spacer();
        alarm(4);
        spacer();
        System.out.println(sum100());
        spacer();
        System.out.println(maxOfTwo(5, 8));
        spacer();
        System.out.println(sumRange(3, 10));
        spacer();
        System.out.println(larger(2.5, 9.2));
        spacer();
        System.out.println(countA("Apples are amazing!"));
        spacer();
        System.out.println(evenlyDivisible(2, 4));
        spacer();
        System.out.println(average(4, 5));
        spacer();
        System.out.println(average(2, 4, 6));
        spacer();
        System.out.println(average(2, 4, 6, 8));
        spacer();
        System.out.println(average(2, 4, 6, 8, 10));
        spacer();
        System.out.println(multiConcat("Hello", 5));
        spacer();
        System.out.println(isAlpha('A'));
        spacer();
        System.out.println(reverse("Fishsticks"));
        spacer();
        System.out.println(isIsoceles(3, 7, 12));
        spacer();
        System.out.println(randomInRange(10, 100));
    }

    /*
     * Pre: Give method a name and an integer
     * Post: returns a welcome message
     */
    public static String countsGuests(String visitorName, int visitorNumber) {
        return "Welcome," + visitorName + "! You are visitor #" +visitorNumber;
    }

    /*
     * Pre:  Accept numbers to count
     * Post:  Return alarm int number amount of times
              
     */
    public static void alarm(int number) {
        for (int i = 0; i < number; i++){
            if (number < 1){
                System.out.println("Error, number for alarm cannot be less than 1.");
            }
            System.out.println("Alarm!");
        }
            
    }

    /*
     * Pre: Accept numbers between 1-100 inclusive
     * Post: Return sum of the numbers 
     */
    public static int sum100() {
      int sum = 0;  
      for (int i = 1; i <= 100; i++){
          sum += i;
      }
      return sum;
    }

    /*
     * Pre: Accept x and y to determine which number is larger 
     * Post: Return larger of the two numbers 
     */
    public static int maxOfTwo(int x, int y) {
        if (x > y){
            return x;
        }
        else {
            return y;
        }
        
    }

    /*
     * Pre: Take in  two numbers 
     * Post: Return sum of the range of the numbers 
     */
    public static int sumRange(int x, int y) {
        int sum = 0;
        if (y < x){
            System.out.println("Error. Invalid input!");
            return 0;
        }
        for (int i = x; x <= y; i++){
            sum += i;
        }
        return sum; 
    }

    /*
     * Pre: Accept x and y as integers 
     * Post: Return true if x > y, false if y > x 
     */
    public static boolean larger(double x, double y) {
       if (x > y){
           return true;
       }
       else {
           return false;
       }
    }

    /*
     * Pre: Accept a string 
     * Post: Return how many times the letter 'A' appears in the string
     */
    public static int countA(String str) {
        int counter = 0;
        for (int i = 0; i < str.length(); i++){
            if (str.charAt(i) == 'A'){
                counter++;
            }    
        }
        return counter;
    }

    /*
     * Pre:  Accept two numbers to see if they are evenly divisible
     * Post: Return true if they are evenly divisible, false otherwise
     */
    public static boolean evenlyDivisible(int x, int y) {
        if (x == 0 || y == 0){
            return false;
        }
        if (x%y == 0 || y%x == 0){
            return true;
        }
        else {
            return false;
        }
    }

    /*
     * Pre:  Accept two numbers
     * Post:  Return average of two numbers
     */
    public static float average(int x, int y) {
        return (x+y) / 2;
        
    }

    /*
     * Pre:  Accept three numbers
     * Post:  Return average of three numbers
     */
    public static float average(int x, int y, int z) {
        return (x+y+z) / 3;
    }

    /*
     * Pre:  Accept four numbers
     * Post:  Return average of four numbers
     */
    public static float average(int x, int y, int z, int a) {
        return (x+y+z+a) / 4;
    }

    /*
     * Pre:  Accept five numbers
     * Post:  Return average of five numbers
     */
    public static float average(int x, int y, int z, int a, int b) {
        return (x+y+z+a+b) / 5;
    }

    /*
     * Pre:  Accept string and int
     * Post:  Return the string int number of times
     */
    public static String multiConcat(String str, int x) {
      String output = str;
      for (int i = 2; i <= x; i++){
          output+=str;
      }
      return output;
    }

    /*
     * Pre:  Accept a char
     * Post:  Return true if the char is a letter in the alphabet, false otherwise
     */
    public static boolean isAlpha(char x) {
        System.out.print(x + " is uppercase or lowercase? ");
        if ((x >= 'a' && x <= 'z') || x >= 'A' && x <= 'Z') {
            return (true);
        } else {
            return (false);
        }
    }

    /*
     * Pre:  Take in a string
     * Post: Return the string in reverse order
     */
    public static String reverse(String str) {
        String output = "";
        for (int i = str.length()-1; i >= 0; i--){
            output += str.charAt(i);
        }
        return output;   
    }

    /*
     * Pre:  Take in integers for sides of a triangle
     * Post:  Return true if the triangle is isoceles, false otherwise
            
     */
    public static boolean isIsoceles(int opp, int adj, int hyp) {
        if ((opp == adj) && (opp != hyp) ||(adj == hyp) && (adj != opp) || (opp == hyp) && (opp != adj) ){
            return true;
        }
        else {
            return false;
        }
    }

    /*
     * Pre:  Take in two integers
     * Post:  Return range of random numbers in range of integers
     */
    public static int randomInRange(int x, int y) {
        int output = 0;
        Random number = new Random();
        if (x <= y){
            int range = y - x + 1;
            output = number.nextInt(range) + x;
        }
        return output;
    }

    /*
     * Pre: 
     * Post: returns a string
     */
    public static void spacer() {
        System.out.println("\n----- Method #" + N + " -----\n");
        N++;
    }
}
